// User_Setup.h - Configuració per GC9A01 amb ESP8266

#ifndef USER_SETUP_H
#define USER_SETUP_H

// Defineix el controlador de pantalla
#define GC9A01_DRIVER

// Definició de pins per ESP8266
#define TFT_MISO  D6  // No necessari per a GC9A01
#define TFT_MOSI  D7  // Sortida de dades SPI
#define TFT_SCLK  D5  // Rellotge SPI
#define TFT_CS    D8  // Chip Select (CS)
#define TFT_DC    D3  // Data/Command
#define TFT_RST   D4  // Reset (-1 si es connecta directament a 3.3V)
#define TFT_BL    D1  // Control de la llum de fons (opcional)

// Fonts carregades
#define LOAD_GLCD      // Petita font de 8 píxels
#define LOAD_FONT2     // Font de 16 píxels
#define LOAD_FONT4     // Font mitjana de 26 píxels
#define LOAD_GFXFF     // Fonts Adafruit GFX
#define SMOOTH_FONT    // Per fonts més suaus

// Configuració de la freqüència SPI
#define SPI_FREQUENCY       27000000   // Millor velocitat per ESP8266
#define SPI_READ_FREQUENCY  20000000

#endif // USER_SETUP_H